globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/YoLOT8nb5K3BVw5vdIwXo/_buildManifest.js",
    "static/YoLOT8nb5K3BVw5vdIwXo/_ssgManifest.js",
    "static/YoLOT8nb5K3BVw5vdIwXo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3j-6o0ylngulp.js",
    "static/chunks/2kqrbujyxigm8.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/3w3pv18cwn0xy.js",
    "static/chunks/turbopack-1-g6kkj94bqgi.js"
  ]
};
