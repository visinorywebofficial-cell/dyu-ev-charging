module.exports=[77762,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ev-charging-station-franchise_page_actions_0g76_14.js.map