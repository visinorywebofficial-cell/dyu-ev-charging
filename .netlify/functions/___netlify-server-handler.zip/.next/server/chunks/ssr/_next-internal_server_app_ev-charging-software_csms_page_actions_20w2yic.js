module.exports=[37411,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ev-charging-software_csms_page_actions_20w2yic.js.map