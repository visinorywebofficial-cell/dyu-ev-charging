module.exports=[39935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_csms-dashboard_page_actions_1rb12fl.js.map