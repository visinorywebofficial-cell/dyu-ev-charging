module.exports=[51561,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_adwall_page_actions_1tm78mn.js.map