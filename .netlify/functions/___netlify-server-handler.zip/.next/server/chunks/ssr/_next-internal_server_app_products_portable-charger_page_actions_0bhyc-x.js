module.exports=[18443,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_portable-charger_page_actions_0bhyc-x.js.map