module.exports=[45368,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-with-us_page_actions_0q57esq.js.map