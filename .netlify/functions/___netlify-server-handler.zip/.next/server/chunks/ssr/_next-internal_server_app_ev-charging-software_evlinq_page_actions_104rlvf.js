module.exports=[9664,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ev-charging-software_evlinq_page_actions_104rlvf.js.map