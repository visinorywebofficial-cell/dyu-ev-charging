module.exports=[44775,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ev-calculator_page_actions_1vh7o-s.js.map